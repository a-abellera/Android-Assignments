# ===========================================================================
# ImportDependencies.cmake
#
# Downloads and configures third-party libraries needed for the desktop build.
# Android and Emscripten have their own GL implementations and do not use this.
#
# Dependencies:
#   GLFW  � window creation and input
#   GLEW  � OpenGL extension loader (static build)
# ===========================================================================

include(FetchContent)

function(importDependencies)

    if(ANDROID)
        # Android has GLESv3 built-in; nothing to fetch here.
        return()
    endif()

    # -----------------------------------------------------------------------
    # GLFW � window and input management
    # -----------------------------------------------------------------------
    if(NOT EMSCRIPTEN)
        message(STATUS "[ImportDependencies] Fetching GLFW ...")
        FetchContent_Declare(
                glfw
                GIT_REPOSITORY https://github.com/glfw/glfw.git
                GIT_TAG        master
                GIT_SHALLOW    TRUE
        )
        set(GLFW_BUILD_DOCS     OFF CACHE BOOL "" FORCE)
        set(GLFW_BUILD_TESTS    OFF CACHE BOOL "" FORCE)
        set(GLFW_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
        FetchContent_MakeAvailable(glfw)
    endif()

    # -----------------------------------------------------------------------
    # GLM — header-only math library
    # -----------------------------------------------------------------------
    message(STATUS "[ImportDependencies] Fetching GLM ...")
    FetchContent_Declare(
            glm
            GIT_REPOSITORY https://github.com/g-truc/glm.git
            GIT_TAG        1.0.1
            GIT_SHALLOW    TRUE
    )
    FetchContent_MakeAvailable(glm)

    # -----------------------------------------------------------------------
    # GLEW � OpenGL extension loader (static)
    # -----------------------------------------------------------------------
    if(NOT EMSCRIPTEN)
        message(STATUS "[ImportDependencies] Fetching GLEW ...")
        FetchContent_Declare(
                glew
                GIT_REPOSITORY https://github.com/Perlmint/glew-cmake.git
                GIT_TAG        master
                GIT_SHALLOW    TRUE
        )
        set(glew-cmake_BUILD_SHARED OFF CACHE BOOL "" FORCE)
        set(glew-cmake_BUILD_STATIC ON  CACHE BOOL "" FORCE)
        FetchContent_MakeAvailable(glew)
    endif()

    message(STATUS "[ImportDependencies] All desktop dependencies ready.")

endfunction()
