/**
 * NativeTemplate.cpp
 *
 * JNI bridge between the Java/Android layer and the shared C++ rendering engine.
 *
 * Native method signatures match MainActivity.java:
 *   package com.example.fan3d
 *   class   MainActivity
 */

#define LOG_TAG "Fan3DNative"
#ifndef PLATFORM_ANDROID
#define PLATFORM_ANDROID
#endif

#include <jni.h>
#include <android/log.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>

#include "Renderer.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_example_fan3d_MainActivity_nativeInit(
        JNIEnv* env, jobject /* thiz */, jobject assetManager)
{
    LOGI("nativeInit called");
    AAssetManager* mgr = AAssetManager_fromJava(env, assetManager);
    if (!mgr) { LOGE("Failed to obtain AAssetManager"); return JNI_FALSE; }
    Renderer::Instance().setAssetManager(mgr);
    return Renderer::Instance().initializeRenderer() ? JNI_TRUE : JNI_FALSE;
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_fan3d_MainActivity_nativeResize(
        JNIEnv* /* env */, jobject /* thiz */, jint width, jint height)
{
    Renderer::Instance().resize(width, height);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_fan3d_MainActivity_nativeRender(
        JNIEnv* /* env */, jobject /* thiz */)
{
    Renderer::Instance().render();
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_fan3d_MainActivity_nativeTouchDown(
        JNIEnv* /* env */, jobject /* thiz */, jfloat x, jfloat y)
{
    Renderer::Instance().TouchEventDown(x, y);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_fan3d_MainActivity_nativeTouchMove(
        JNIEnv* /* env */, jobject /* thiz */, jfloat x, jfloat y)
{
    Renderer::Instance().TouchEventMove(x, y);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_fan3d_MainActivity_nativeTouchRelease(
        JNIEnv* /* env */, jobject /* thiz */, jfloat x, jfloat y)
{
    Renderer::Instance().TouchEventRelease(x, y);
}
